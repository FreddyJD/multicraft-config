<?php
// FROM HASH: 4ff0cf02b6b1d79ad55e1e620f238179
return array('macros' => array(), 'code' => function($__templater, array $__vars)
{
	$__finalCompiled = '';
	$__finalCompiled .= '<div class="contentRow-figure contentRow-figure--fixedBookmarkIcon">
	<div class="contentRow-figureIcon">
		' . $__templater->fontAwesome('fa-file-alt fa-3x', array(
	)) . '
	</div>
</div>';
	return $__finalCompiled;
});