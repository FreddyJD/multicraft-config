<?php
// FROM HASH: 499e605eb4959b496de9b5ee8b152fb5
return array('macros' => array(), 'code' => function($__templater, array $__vars)
{
	$__finalCompiled = '';
	$__finalCompiled .= '<!-- oEmbed - template usused -->';
	return $__finalCompiled;
});