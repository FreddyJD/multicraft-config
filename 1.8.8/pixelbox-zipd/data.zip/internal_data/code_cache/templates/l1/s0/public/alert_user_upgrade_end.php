<?php
// FROM HASH: a139e2fa0d7763df5d9be80c19143e4e
return array('macros' => array(), 'code' => function($__templater, array $__vars)
{
	$__finalCompiled = '';
	$__finalCompiled .= 'One of your account upgrades has expired. <a href="' . $__templater->func('link', array('account/upgrades', ), true) . '" data-tp-primary="on">Renew now!</a>';
	return $__finalCompiled;
});