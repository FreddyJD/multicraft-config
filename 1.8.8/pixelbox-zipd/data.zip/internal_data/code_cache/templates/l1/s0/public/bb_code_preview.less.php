<?php
// FROM HASH: 233506835cd419181c716976667b6eaf
return array('macros' => array(), 'code' => function($__templater, array $__vars)
{
	$__finalCompiled = '';
	$__finalCompiled .= '.bbCodePreview
{
	.m-transitionFadeDown();
}

.bbCodePreview-content
{
	max-height: 300px;
	max-height: 75vh;
	overflow: auto;
	padding-bottom: 3px; // mostly to ensure icode doesn\'t overflow unexpectedly
	font-family: @xf-fontFamilyBody;
}';
	return $__finalCompiled;
});