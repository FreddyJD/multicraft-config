<?php
// FROM HASH: f92be850c77e04da5b1fc81d58d67a8a
return array('macros' => array(), 'code' => function($__templater, array $__vars)
{
	$__finalCompiled = '';
	$__finalCompiled .= '<div class="bbMediaWrapper">
	<div class="bbMediaWrapper-inner">
		<iframe width="560" height="315"
				src="http://www.metacafe.com/embed/' . $__templater->escape($__vars['id']) . '/"
				frameborder="0" allowfullscreen="true"></iframe>
	</div>
</div>';
	return $__finalCompiled;
});