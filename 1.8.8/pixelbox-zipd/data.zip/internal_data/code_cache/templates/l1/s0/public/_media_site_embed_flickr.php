<?php
// FROM HASH: 2de30b819948096a9ff1e1fc002a91e8
return array('macros' => array(), 'code' => function($__templater, array $__vars)
{
	$__finalCompiled = '';
	$__finalCompiled .= '<!-- oEmbed - template unused -->';
	return $__finalCompiled;
});