<?php
// FROM HASH: a6b63946331dc38117d8c168b24a263d
return array('macros' => array(), 'code' => function($__templater, array $__vars)
{
	$__finalCompiled = '';
	$__finalCompiled .= '<div class="bbMediaWrapper">
	<div class="bbMediaWrapper-inner">
		<iframe src="' . $__templater->escape($__vars['url']) . '"
			width="560" height="315"
			frameborder="0" allowfullscreen="true"
			scrolling="no"></iframe>
	</div>
</div>';
	return $__finalCompiled;
});