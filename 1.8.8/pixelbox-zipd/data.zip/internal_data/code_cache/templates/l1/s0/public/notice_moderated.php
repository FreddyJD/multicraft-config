<?php
// FROM HASH: c453050ed6fc03fade18e2eb11ada93f
return array('macros' => array(), 'code' => function($__templater, array $__vars)
{
	$__finalCompiled = '';
	$__finalCompiled .= 'Your account is currently awaiting approval by an administrator. You will receive an email when a decision has been taken.';
	return $__finalCompiled;
});