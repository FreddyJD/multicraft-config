<?php
// FROM HASH: 735e100c5cb6c07967191a750a13364a
return array('macros' => array(), 'code' => function($__templater, array $__vars)
{
	$__finalCompiled = '';
	$__finalCompiled .= '<div class="bbMediaWrapper">
	<div class="bbMediaWrapper-inner bbMediaWrapper-inner--4to3">
		<iframe src="https://giphy.com/embed/' . $__templater->escape($__vars['id']) . '"
			width="500"
			height="375"
			frameborder="0"
			allowfullscreen></iframe>
	</div>
</div>';
	return $__finalCompiled;
});