<?php
// FROM HASH: 19712958d8a9c55864659ccce36d9653
return array('macros' => array(), 'code' => function($__templater, array $__vars)
{
	$__finalCompiled = '';
	$__finalCompiled .= $__templater->filter($__vars['extra']['alert_text'], array(array('raw', array()),), true);
	return $__finalCompiled;
});