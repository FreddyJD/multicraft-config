<?php
// FROM HASH: d41d8cd98f00b204e9800998ecf8427e
return array('macros' => array(), 'code' => function($__templater, array $__vars)
{
	$__finalCompiled = '';
	$__finalCompiled .= '';
	return $__finalCompiled;
});