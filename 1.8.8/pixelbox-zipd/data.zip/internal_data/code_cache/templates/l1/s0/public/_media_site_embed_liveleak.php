<?php
// FROM HASH: 292595c6c888f510fa3c09042a344698
return array('macros' => array(), 'code' => function($__templater, array $__vars)
{
	$__finalCompiled = '';
	$__finalCompiled .= '<div class="bbMediaWrapper">
	<div class="bbMediaWrapper-inner">
		<iframe src="http://www.liveleak.com/ll_embed?i=' . $__templater->escape($__vars['id']) . '"
				width="560" height="315"
				frameborder="0" allowfullscreen="true"></iframe>
	</div>
</div>';
	return $__finalCompiled;
});