<?php

namespace XF\Repository;

class ThreadPrompt extends AbstractPrompt
{
	protected function getClassIdentifier()
	{
		return 'XF:ThreadPrompt';
	}
}